import glob
from setuptools import setup

setup(
    data_files=glob.glob("onisubscriptions/*.json"),
)